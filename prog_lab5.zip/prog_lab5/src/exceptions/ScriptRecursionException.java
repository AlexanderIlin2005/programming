package exceptions;

public class ScriptRecursionException extends Exception {}
