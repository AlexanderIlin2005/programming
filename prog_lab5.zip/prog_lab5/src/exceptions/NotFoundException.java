package exceptions;

public class NotFoundException extends Exception {}
