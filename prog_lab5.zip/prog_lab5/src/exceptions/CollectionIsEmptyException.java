package exceptions;

public class CollectionIsEmptyException extends Exception{
}
