package exceptions;

public class WrongAmountOfElementsException extends Exception {}
