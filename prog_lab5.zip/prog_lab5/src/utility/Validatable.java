package utility;

@FunctionalInterface
public interface Validatable {
    public boolean validate();
}
