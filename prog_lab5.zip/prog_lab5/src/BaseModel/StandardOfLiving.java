package BaseModel;

public enum StandardOfLiving {
    ULTRA_HIGH,
    MEDIUM,
    VERY_LOW,
    ULTRA_LOW,
    NIGHTMARE;
}
