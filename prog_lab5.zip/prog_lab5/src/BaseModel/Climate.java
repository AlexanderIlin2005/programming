package BaseModel;

public enum Climate {
    RAIN_FOREST,
    TROPICAL_SAVANNA,
    MEDITERRANIAN,
    STEPPE,
    DESERT;
}